---
title: SAA Website
author: Li Zihan 
---


**Abstract**
---

SAA is Student Alumni Association of SJTU-UM JI. We made a website for the organization to demo what we have done during the year 2016. There are also resources made by former JI students shared on the website to give a quick intro to coming JI DD students. We made the website based on React and Meteor. 

![saa-website](/pic/saa-website/1.png)

This project is made together with Wen He and Gaole Meng. 



