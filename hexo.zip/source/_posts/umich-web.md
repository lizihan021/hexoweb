---
title: Umich Website Theme "Menc"
author: Li Zihan 
---


**Abstract**
---

University of Michigan was planning to migrate its website content from Plone CMS to WordPress. Developed part of the Umich WordPress theme "Menc" during my intern. 

![umich web theme](/pic/umich-web/1.png)

