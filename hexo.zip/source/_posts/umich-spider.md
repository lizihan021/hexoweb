---
title: Umich Website Spider
author: Li Zihan 
---

**Abstract**
---

University of Michigan was planning to migrate its website content from Plone CMS to WordPress. I wrote a web spider to collect all posts from the original website during my intern to help the migration. 

![umich web spider](/pic/umich-spider/1.png)

The tool was also able to upload website content to google drive. 